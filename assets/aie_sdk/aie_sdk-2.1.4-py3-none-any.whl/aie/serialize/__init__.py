#!/usr/bin/env python
# -*- coding: utf-8 -*-

from .serializer_impl import Serializer
serializer = Serializer()
